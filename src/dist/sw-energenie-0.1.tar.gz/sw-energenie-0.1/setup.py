from setuptools import setup

setup(name='sw-energenie', version='0.1', scripts=['__init__'])